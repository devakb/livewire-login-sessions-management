<?php

namespace App\Http\Livewire\LoginSession;

use Livewire\Component;
use App\Models\LoginSession;
use App\Rules\IsCurrentPassword;
use Illuminate\Support\Facades\Auth;

class LoginSessionsComponent extends Component
{
    public $current_password;

    protected $listeners = ['refreshAllLoginSessionsComponent' => '$refresh'];

    public function render()
    {
        $loginSessions = LoginSession::whereUserId(auth()->user()->id)->orderby('last_activity', 'DESC')->get();
        return view('livewire.login-session.all-login-sessions-component', compact('loginSessions'));
    }

    public function proceed(){
        $this->validate([
            'current_password' => [
                'required',
                new IsCurrentPassword,
            ],
        ]);

        $user_id = Auth()->user()->id;
        LoginSession::whereUserId(auth()->user()->id)->delete();
        Auth::loginUsingId($user_id);

        $this->emit('refreshAllLoginSessionsComponent');
        $this->reset();
        $this->dispatchBrowserEvent('reloadLoginSessions');
    }
}
