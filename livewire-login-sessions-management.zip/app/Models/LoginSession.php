<?php

namespace App\Models;

use Jenssegers\Agent\Agent;
use Illuminate\Database\Eloquent\Model;

class LoginSession extends Model
{
    protected $table = 'sessions';
    public $incrementing = false;

    public $appends = [
        'platform',
        'browser',
        'is_current',
        'agent',

    ];

    protected $hidden = [
        'id',
        'payload',
    ];


    public function getPlatformAttribute(){
        return (new Agent())->platform();
    }

    public function getBrowserAttribute(){
        return (new Agent())->browser();
    }


    public function getIsCurrentAttribute(){

        if($this->id == request()->session()->getId()){
            return true;
        }else{
            return false;
        }

    }

    public function getAgentAttribute(){
        return (new Agent());
    }

}
