<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h3 class="h3">Where you’re signed in</h3>
            <p class="small text-muted">Manage and logout your active sessions on other browsers and devices.</p>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <p class="small mb-4">
                        If necessary, you may logout of all of your other browser session across all of your devices.
                        If you feel your account has been compromised, you should also update your password.
                    </p>

                    <table class="table table-borderless">
                        @foreach($loginSessions as $loginSession)
                            <tr>
                                <div class="d-flex align-items-center">
                                    @if ($loginSession->agent->isDesktop())
                                        <svg fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor"  style="width: 29px;height: 29px;">
                                            <path d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                        </svg>
                                    @else
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round" style="width: 35px;height: 35px;">
                                            <path d="M0 0h24v24H0z" stroke="none"></path><rect x="7" y="4" width="10" height="16" rx="1"></rect><path d="M11 5h2M12 17v.01"></path>
                                        </svg>
                                    @endif
                                    <div class="ml-2">
                                        <h6 class="h6 font-weight-normal">
                                            {{ $loginSession->platform }} - {{ $loginSession->browser }}
                                        </h6>
                                        <p class="small text-muted">
                                           {{ $loginSession->ip_address }}

                                            @if($loginSession->is_current) &bull; <b class="text-success">This Device</b> @endif
                                        </p>
                                    </div>
                                </div>
                                <br>
                            </tr>
                        @endforeach
                    </table>


                    <button type="button" class="btn btn-dark btn-sm px-3 py-2 text-uppercase font-weight-600" data-toggle="modal" data-target="#livewireSessionCloseModal">
                        Logout Other Browser Sessions
                    </button>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" wire:ignore.self data-backdrop="static" data-keyboard="false"  id="livewireSessionCloseModal" tabindex="-1" role="dialog" aria-labelledby="livewireSessionCloseModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document" >
          <div class="modal-content" >
            <div class="modal-body">
                <h5 class="font-weight-normal mb-2">
                    Logout Other Browser Sessions
                </h6>
                <p class="text-muted">
                    Please enter your password to confirm you would like to logout of your other browser sessions across all of your devices.
                </p>
                <br>
              <form wire:submit.prevent="proceed">
                  <div class="form-group">
                        <input type="password" wire:model.defer="current_password" class="form-control @error('current_password') is-invalid @enderror" placeholder="Password">
                        @error('current_password')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                  </div>

                  <div class="form-group text-right">
                    <button type="button" class="btn btn-danger btn-sm px-3 text-uppercase font-weight-600" id="livewireSessionCloseModalDismis" data-dismiss="modal" aria-label="Close">Nevermind</button>
                    <button type="submit" class="btn btn-dark btn-sm px-3 text-uppercase font-weight-600">Proceed</button>
                  </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      @section('scripts')
        <script>
            window.addEventListener('reloadLoginSessions', function(){
                $('#livewireSessionCloseModalDismis').click();
            })
        </script>
      @endsection
</div>



